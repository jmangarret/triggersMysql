<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

$languageStrings = array(
	'ComisionSatelites' => 'Comisiones Satelites',
	'SINGLE_ComisionSatelites' => 'Comision Satelite',
	'LBL_BLOCK_GENERAL_INFORMATION' => '',
	'LBL_BLOCK_SYSTEM_INFORMATION' => '',
	'LBL_ACCOUNTID' => 'Cuenta Satelite',
	'LBL_ACTIVA' => 'Activa',
	'LBL_TIPODECOMISIONID' => 'Tipo de Comisión',
	'LBL_BASE' => 'Base de Comisión',
	'LBL_TIPODEFORMULA' => 'Tipo de Fórmula',

);

?>
